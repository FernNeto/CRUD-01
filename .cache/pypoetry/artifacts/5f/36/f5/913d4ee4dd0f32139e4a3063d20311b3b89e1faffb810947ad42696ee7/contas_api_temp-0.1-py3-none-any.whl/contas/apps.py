"""
Criado automaticamente pelo comando:
$ django-admin startapp usuarios
"""
from django.apps import AppConfig


class ContasConfig(AppConfig):
    """
    Criado automaticamente pelo comando:
    $ django-admin startapp usuarios
    """
    name = 'contas'
