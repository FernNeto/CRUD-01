"""
Criado automaticamente pelo comando:
$ django-admin startapp usuarios
"""
# from django.contrib import admin
