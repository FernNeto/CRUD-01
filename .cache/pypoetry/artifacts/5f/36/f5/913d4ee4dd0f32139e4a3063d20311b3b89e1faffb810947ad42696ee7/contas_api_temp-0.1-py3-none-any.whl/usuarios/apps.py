"""
Criado automaticamente pelo comando:
$ django-admin startapp usuarios
"""

from django.apps import AppConfig


class UsuariosConfig(AppConfig):
    """
    Criado automaticamente pelo comando:
    $ django-admin startapp usuarios
    """
    name = 'usuarios'
