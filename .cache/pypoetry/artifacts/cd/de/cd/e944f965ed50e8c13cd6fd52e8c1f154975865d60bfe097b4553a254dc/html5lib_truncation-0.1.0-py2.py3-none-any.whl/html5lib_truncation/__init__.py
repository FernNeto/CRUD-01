from .filters import TruncationFilter
from .shortcuts import truncate_html

__all__ = ['TruncationFilter', 'truncate_html']
__version__ = '0.1.0'
