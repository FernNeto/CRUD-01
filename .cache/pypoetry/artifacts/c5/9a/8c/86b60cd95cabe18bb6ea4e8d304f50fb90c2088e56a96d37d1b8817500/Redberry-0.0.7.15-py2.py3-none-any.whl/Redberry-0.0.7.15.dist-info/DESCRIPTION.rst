Flask Blueprint for adding simple CMS functionality


